const SpellChecker = require("spellchecker");

const lambdaFunc = async (event) => {
  const text = event.text.split(" ");
  let correctText = "";

  for(let i = 0; i < text.length; i++) {
    if(SpellChecker.isMisspelled(text[i])) {
      correctText += SpellChecker.getCorrectionsForMisspelling(text[i])[0] + " ";
      continue;
    }

    correctText += text[i] + " "; 
  }

  const response = {
      statusCode: 200,
      body: JSON.stringify(correctText),
  };
  return response;
};

exports.handler = lambdaFunc;
